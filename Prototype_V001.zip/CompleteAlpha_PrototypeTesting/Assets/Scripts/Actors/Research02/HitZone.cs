﻿using UnityEngine;

[AddComponentMenu("Scripts/Destroyables/HitZone")]
public class HitZone : MonoBehaviour
{

}