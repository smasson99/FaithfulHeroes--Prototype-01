﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

[AddComponentMenu("Scripts/Entitys/BasicMobEntity")]
public class BasicMobEntity : CharacterEntity
{

}
